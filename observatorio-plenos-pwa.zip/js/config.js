// Configuración pública de Supabase. La clave anon/publishable puede estar en el frontend si RLS está bien configurado.
window.OBS_CONFIG = {
  url: "https://rvwdvmfghjafxpyyleqv.supabase.co",
  anonKey: "PEGA_AQUI_TU_CLAVE_PUBLICA_ANON_O_PUBLISHABLE"
};
